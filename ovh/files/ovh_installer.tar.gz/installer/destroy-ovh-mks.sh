#!/bin/bash
# ============================================================
# OVHcloud MKS Teardown — destroys ALL infrastructure
# WARNING: This will permanently delete the cluster, all node
#          pools, Manila NFS share, private network,
#          S3 bucket, and cloud user.
# ============================================================
# Usage:
#   micromamba activate ovh
#   cd OVH_installer/installer
#   ./destroy-ovh-mks.sh
# ============================================================
set -euo pipefail

export ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; NC='\033[0m'
ok()   { echo -e "${GREEN}✅ $*${NC}"; }
warn() { echo -e "${YELLOW}⚠  $*${NC}"; }
die()  { echo -e "${RED}❌ $*${NC}"; exit 1; }

# Load env
set -a; source "$ROOT_DIR/env.variables"; set +a

echo -e "${RED}"
echo "=========================================================="
echo "  WARNING: This will PERMANENTLY DELETE:"
echo "    - MKS cluster:       ${K8S_CLUSTER_NAME} (${OVH_REGION})"
echo "    - Manila NFS share:  ${FILE_STORAGE_SHARE_NAME:-<see env.variables>}"
echo "    - Share network:     tes-share-network"
echo "    - Private network:   ${PRIV_NET_NAME:-tes-private-net}"
echo "    - S3 bucket:         ${OVH_S3_BUCKET}  (ALL CONTENTS)"
echo "    - Cloud user:        ${KUBE_USER_ID:-<unknown>}"
echo "    - Kubeconfig:        ${KUBECONFIG_PATH}"
echo "=========================================================="
echo -e "${NC}"
read -rp "Type 'yes' to confirm full teardown: " CONFIRM
[ "$CONFIRM" != "yes" ] && die "Aborted."

# ── 1. Delete Funnel K8s resources (graceful before cluster delete)
if [ -f "${KUBECONFIG_PATH}" ]; then
    export KUBECONFIG="${KUBECONFIG_PATH}"
    echo "Deleting Funnel Kubernetes resources..."
    kubectl delete namespace "${TES_NAMESPACE}" --ignore-not-found --timeout=60s || true

    # Manila CSI: uninstall Helm releases + delete RBAC that blocks re-install
    echo "Uninstalling Manila CSI Helm releases..."
    helm uninstall manila-csi    -n kube-system 2>/dev/null || warn "manila-csi not installed via Helm or already removed"
    helm uninstall csi-driver-nfs -n kube-system 2>/dev/null || warn "csi-driver-nfs not installed via Helm or already removed"

    # Delete cloud-config Secret (contains clouds.yaml; safe to remove)
    kubectl delete secret cloud-config -n kube-system --ignore-not-found || true

    # Delete funnel-work-* PVCs + mount-holder pods (reclaimPolicy: Retain — must delete manually)
    echo "Deleting funnel-work disk-monitor pods and PVCs..."
    kubectl delete pods -n "${TES_NAMESPACE}" -l app=funnel-mount-holder --ignore-not-found || true
    kubectl delete pvc  -n "${TES_NAMESPACE}" -l app=funnel-disk-monitor  --ignore-not-found || true

    # Delete StorageClasses (manila-nfs is the only CSI-backed one; funnel-* are not created)
    kubectl delete storageclass manila-nfs --ignore-not-found || true

    # Delete manila-pvc PV + PVC (they use ReclaimPolicy: Retain — must delete manually)
    kubectl delete pvc manila-shared-pvc -n "${TES_NAMESPACE}" --ignore-not-found || true
    kubectl delete pv  manila-shared-pv  --ignore-not-found || true

    ok "Kubernetes resources deleted"
else
    warn "Kubeconfig not found at ${KUBECONFIG_PATH}; skipping K8s cleanup"
fi

# ── 2. Delete Manila access rule
if [ -n "${MANILA_ACCESS_ID:-}" ] && [ -n "${MANILA_SHARE_ID:-}" ]; then
    echo "Deleting Manila access rule ${MANILA_ACCESS_ID}..."
    openstack share access delete "${MANILA_SHARE_ID}" "${MANILA_ACCESS_ID}" 2>/dev/null \
        || warn "Manila access rule delete failed or already removed"
    ok "Manila access rule deleted"
else
    warn "MANILA_ACCESS_ID or MANILA_SHARE_ID not set; skipping access rule deletion"
fi

# ── 3. Delete Manila share
if [ -n "${MANILA_SHARE_ID:-}" ]; then
    echo "Deleting Manila share ${MANILA_SHARE_ID} (${FILE_STORAGE_SHARE_NAME:-})..."
    openstack share delete "${MANILA_SHARE_ID}" 2>/dev/null \
        || warn "Manila share delete failed or already removed"
    # Wait briefly for the share to be removed before deleting the share network
    echo "Waiting for share deletion..."
    for i in $(seq 1 20); do
        STATUS=$(openstack share show "${MANILA_SHARE_ID}" -c status -f value 2>/dev/null || echo "deleted")
        [ "${STATUS}" = "deleted" ] && break
        echo "  [${i}/20] Share status: ${STATUS} — waiting 10s..."
        sleep 10
    done
    ok "Manila share deleted (or already gone)"
else
    warn "MANILA_SHARE_ID not set; skipping share deletion"
fi

# ── 4. Delete Manila share network
SHARE_NET_NAME="tes-share-network"
EXISTING_SN=$(openstack share network list -c ID -c Name -f value 2>/dev/null \
    | awk -v n="${SHARE_NET_NAME}" '$0 ~ n {print $1}' | head -1 || true)
if [ -n "${EXISTING_SN:-}" ]; then
    echo "Deleting share network ${SHARE_NET_NAME} (${EXISTING_SN})..."
    openstack share network delete "${EXISTING_SN}" 2>/dev/null \
        || warn "Share network delete failed or already removed"
    ok "Share network deleted"
else
    warn "Share network '${SHARE_NET_NAME}' not found; skipping"
fi

# ── 5. Delete MKS cluster (this also deletes all node pools and their instances)
if [ -n "${KUBE_ID:-}" ]; then
    echo "Deleting MKS cluster ${K8S_CLUSTER_NAME} (id: ${KUBE_ID})..."
    ovhcloud cloud kube delete "${KUBE_ID}" \
        --cloud-project "${OVH_PROJECT_ID}" \
        2>/dev/null || warn "Cluster delete failed or already deleted"
    ok "MKS cluster deletion triggered (may take a few minutes)"
else
    warn "KUBE_ID not set; skipping cluster deletion"
fi

# ── 6. Delete private Neutron network (must be done AFTER cluster is gone —
#       cluster deletion releases the network's port reservations)
if [ -n "${PRIV_NET_ID:-}" ]; then
    echo "Waiting 60s for cluster instances to release network ports before deleting private network..."
    sleep 60
    echo "Deleting private network '${PRIV_NET_NAME:-tes-private-net}' (OVH id: ${PRIV_NET_ID})..."
    ovhcloud cloud network private delete "${PRIV_NET_ID}" \
        --cloud-project "${OVH_PROJECT_ID}" \
        2>/dev/null || warn "Private network delete failed or already removed (retry in OVH console if needed)"
    ok "Private network deleted"
else
    warn "PRIV_NET_ID not set; skipping private network deletion"
fi

# ── 7. Delete S3 bucket (and all contents)
BUCKET_EXISTS=$(ovhcloud cloud storage-s3 list \
    --cloud-project "${OVH_PROJECT_ID}" --json 2>/dev/null \
    | python3 -c "
import sys,json; data=json.load(sys.stdin)
if not isinstance(data,list): data=[data]
print('yes' if any(b.get('name')=='${OVH_S3_BUCKET}' for b in data) else '')
" 2>/dev/null || echo "")

if [ -n "${BUCKET_EXISTS}" ]; then
    echo "Deleting S3 bucket ${OVH_S3_BUCKET} (all objects will be lost)..."
    ovhcloud cloud storage-s3 bulk-delete \
        --cloud-project "${OVH_PROJECT_ID}" \
        --container-name "${OVH_S3_BUCKET}" \
        --prefix "" 2>/dev/null || warn "Bulk delete failed or bucket already empty"
    ovhcloud cloud storage-s3 delete \
        --cloud-project "${OVH_PROJECT_ID}" \
        --container-name "${OVH_S3_BUCKET}" 2>/dev/null || warn "Bucket delete failed"
    ok "S3 bucket deleted"
else
    warn "S3 bucket '${OVH_S3_BUCKET}' not found; skipping"
fi

# ── 8. Delete OVH cloud user
# NOTE: KUBE_USER_ID is now the PREREQUISITE user created in OVH Manager (step 8).
# This user owns the S3 credentials and is needed for post-cluster access to S3 if desired.
# We do NOT delete it — the user should manage this themselves in OVH Manager if needed.
# Previous versions created a temporary "funnel-s3-user" which was deleted here; that no longer applies.
warn "KUBE_USER_ID (${KUBE_USER_ID:-<not set>}) is the prerequisite OVH cloud user. Not deleted."
warn "To delete it manually: OVH Manager → Public Cloud → Users & Roles → delete the user"

# ── 9. Remove kubeconfig
rm -f "${KUBECONFIG_PATH}" && ok "Kubeconfig removed" || true

echo ""
ok "Teardown complete. Check OVH console to confirm all resources are gone."
echo ""
echo "Cost-incurring resources to verify in OVH console:"
echo "  - Public Cloud → Managed Kubernetes   (no cluster should remain)"
echo "  - Public Cloud → Storage → File Storage (no Manila share should remain)"
echo "  - Public Cloud → Network → Private Networks (tes-private-net deleted)"
echo "  - Public Cloud → Storage → Object Storage  (no bucket)"
echo "  - Public Cloud → Instances           (none after cluster delete)"
echo "  - Public Cloud → Network → Load Balancers  (deleted with cluster, verify)"

